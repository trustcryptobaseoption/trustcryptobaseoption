
import React, { useState, useEffect } from "react";

// Pools of data for randomization
const names = ["James", "Emily", "Carlos", "Aisha", "Michael", "Sophia", "David", "Olivia", "Liam", "Emma"];
const cryptos = [
  { symbol: "BTC", usdValuePerUnit: 50000 },
  { symbol: "ETH", usdValuePerUnit: 3000 },
  { symbol: "USDT", usdValuePerUnit: 1 },
  { symbol: "BNB", usdValuePerUnit: 400 },
  { symbol: "XRP", usdValuePerUnit: 1 },
  { symbol: "LTC", usdValuePerUnit: 150 },
  { symbol: "DOGE", usdValuePerUnit: 0.2 },
];

// Helper functions
function randomBetween(min, max) {
  return Math.random() * (max - min) + min;
}

function randomIntBetween(min, max) {
  return Math.floor(randomBetween(min, max));
}

function formatUSD(amount) {
  return `$${amount.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 0 })}`;
}

function formatCryptoAmount(usdAmount, cryptoPrice) {
  const cryptoAmount = usdAmount / cryptoPrice;
  if (cryptoAmount < 1) {
    return cryptoAmount.toFixed(4);
  }
  return cryptoAmount.toFixed(2);
}

function randomTimeAgo() {
  const minutesAgo = randomIntBetween(5, 60 * 48); // 5 minutes to 48 hours
  if (minutesAgo < 60) {
    return `${minutesAgo} minute${minutesAgo === 1 ? '' : 's'} ago`;
  } else {
    const hours = Math.floor(minutesAgo / 60);
    return `${hours} hour${hours === 1 ? '' : 's'} ago`;
  }
}

function generateTestimonial() {
  const name = names[randomIntBetween(0, names.length)];
  const usdAmount = randomBetween(1900, 100000);
  const crypto = cryptos[randomIntBetween(0, cryptos.length)];

  // To keep variety, sometimes show USD only (especially for USDT)
  const showCryptoAmount = crypto.symbol !== "USDT" && Math.random() > 0.3;

  if (showCryptoAmount) {
    const cryptoAmount = formatCryptoAmount(usdAmount, crypto.usdValuePerUnit);
    return `${name} withdrew ${cryptoAmount} ${crypto.symbol} — ${formatUSD(usdAmount)} (${randomTimeAgo()})`;
  } else {
    return `${name} withdrew ${formatUSD(usdAmount)} ${crypto.symbol} (${randomTimeAgo()})`;
  }
}

export default function DashboardWidgets() {
  // Total users start at 10,200, grow by 5–20 per day since a start date
  const startUsers = 10200;
  const startDate = new Date("2025-06-01T00:00:00Z");

  const [totalUsers, setTotalUsers] = useState(startUsers);
  const [testimonial, setTestimonial] = useState(generateTestimonial());

  useEffect(() => {
    // Update total users based on days passed
    const now = new Date();
    const daysPassed = Math.floor((now - startDate) / (1000 * 60 * 60 * 24));
    const users = startUsers + daysPassed * randomIntBetween(5, 20);
    setTotalUsers(users);
  }, []);

  useEffect(() => {
    // Change testimonial every 7 seconds
    const interval = setInterval(() => {
      setTestimonial(generateTestimonial());
    }, 7000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div style={{ padding: 20, fontFamily: "Arial, sans-serif", color: "#222" }}>
      <div style={{ marginBottom: 20, fontSize: 24, fontWeight: "bold" }}>
        Total Users: {totalUsers.toLocaleString()}
      </div>
      <div style={{
        border: "1px solid #ccc",
        borderRadius: 8,
        padding: 15,
        fontSize: 18,
        backgroundColor: "#f9f9f9",
        maxWidth: 480,
        boxShadow: "0 2px 6px rgba(0,0,0,0.1)"
      }}>
        <strong>Latest Withdrawal:</strong> <em>{testimonial}</em>
      </div>
    </div>
  );
}
