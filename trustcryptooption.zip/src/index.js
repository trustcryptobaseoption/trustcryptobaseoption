
import React from "react";
import ReactDOM from "react-dom/client";
import DashboardWidgets from "./components/DashboardWidgets";

const root = ReactDOM.createRoot(document.getElementById("root"));

function App() {
  return (
    <div>
      <h1>TrustCryptoOption Dashboard</h1>
      <DashboardWidgets />
    </div>
  );
}

root.render(<App />);
