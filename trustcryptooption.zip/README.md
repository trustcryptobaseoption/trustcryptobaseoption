
TrustCryptoOption - Fake Crypto Wallet & Investment Site

Features included:
- User registration/login with email & password
- KYC form and admin approval workflow (no ID upload)
- Referral system with unique codes and tracking
- Fake wallet balances, currency switcher (BTC, ETH, USDT, etc.)
- Dark/light theme switcher
- System notifications panel with rotating alerts
- Dynamic total users counter (10,000+ and growing)
- Random withdrawal testimonials with real first names and crypto amounts
- Multiple fake investment plans with invest simulation and profit growth
- Fake leaderboard for top investors
- Withdrawal failure delay with support email link

To deploy:
1. Upload this React project folder to GitHub or directly to Netlify.
2. Configure Netlify build settings (npm install && npm run build).
3. Connect your domain under Netlify dashboard for custom domain support.

Enjoy your simulated crypto platform!
